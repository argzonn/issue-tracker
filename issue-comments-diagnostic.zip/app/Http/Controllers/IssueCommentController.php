<?php

namespace App\Http\Controllers;

use App\Models\Issue;
use App\Models\Comment;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\View;
use App\Http\Requests\CommentStoreRequest;


class IssueCommentController extends Controller
{
    public function index(Request $request, Issue $issue): JsonResponse
    {
        $comments = $issue->comments()->latest()->paginate(10);
        $html = View::make('issues.partials.comment-items', compact('comments'))->render();

        return response()->json([
            'ok'   => true,
            'html' => $html,
            'next' => $comments->nextPageUrl(),
        ], 200);
    }

    public function store(CommentStoreRequest $request, Issue $issue): JsonResponse
    {
        try {
            // Write without mass-assignment pitfalls
            $comment = new Comment();
            $comment->author_name = $request->string('author_name');
            $comment->body        = $request->string('body');
            $issue->comments()->save($comment);

            // Render a one-item list so the frontend can prepend
            $html = View::make('issues.partials.comment-items', [
                'comments' => new LengthAwarePaginator(
                    collect([$comment->fresh()]), 1, 1, 1
                ),
            ])->render();

            return response()->json(['ok' => true, 'html' => $html], 201);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json(['ok' => false, 'errors' => $e->errors()], 422);
        } catch (\Throwable $e) {
            Log::error('Comment create failed', [
                'issue_id' => $issue->id,
                'user_id'  => optional($request->user())->id,
                'message'  => $e->getMessage(),
                'trace'    => $e->getTraceAsString(),
            ]);
            return response()->json(['ok' => false, 'message' => 'Failed to add comment.'], 500);
        }
    }
}
