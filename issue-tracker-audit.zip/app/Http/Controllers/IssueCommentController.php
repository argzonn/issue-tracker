<?php

namespace App\Http\Controllers;

use App\Http\Requests\CommentStoreRequest;
use App\Models\Issue;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\View;

class IssueCommentController extends Controller
{
    public function index(Request $request, Issue $issue): JsonResponse
    {
        $comments = $issue->comments()->paginate(10);
        $html = View::make('issues.partials.comment-items', compact('comments'))->render();
        return response()->json(['ok' => true, 'html' => $html, 'next' => $comments->nextPageUrl()], 200);
    }

    public function store(CommentStoreRequest $request, Issue $issue): JsonResponse
    {
        $comment = $issue->comments()->create($request->validated());

        // render a single item so the client can prepend it
        $html = View::make('issues.partials.comment-items', [
            'comments' => new LengthAwarePaginator(collect([$comment->fresh()]), 1, 1, 1),
        ])->render();

        return response()->json(['ok' => true, 'html' => $html], 201);
    }
}
