@php $map = ['open'=>'success','in_progress'=>'warning','closed'=>'secondary']; @endphp
<span class="badge text-bg-{{ $map[$status] ?? 'light' }}">{{ ucfirst(str_replace('_',' ', $status)) }}</span>
