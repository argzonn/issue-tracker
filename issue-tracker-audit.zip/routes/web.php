<?php

use Illuminate\Support\Facades\Route;

// Controllers
use App\Http\Controllers\{
    ProjectController,
    IssueController,
    TagController,
    IssueCommentController,
    IssueTagController,
    IssueAssigneeController
};
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\Project;
Route::get('/issues/create', function (Request $request) {
    // simple selector page
    $projects = Project::orderBy('name')->get(['id','name']);
    return view('issues.choose-project', compact('projects'));
})->name('issues.create');


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
| Only the routes your app actually uses. No duplicates. No mismatched
| method names. All AJAX endpoints return JSON (handled in controllers).
*/

// Landing: send folks to Projects
Route::get('/', fn () => redirect()->route('projects.index'));

// ------------------- Auth (if you have auth scaffolding) -------------------
// Leave these to your auth scaffolder (Breeze/Fortify/etc). We just link to them.
// route('login') and route('logout') should already exist via the package.
Route::get('/login', function () {
    // If you don't have real auth screens yet, just land on projects.
    return redirect()->route('projects.index');
})->name('login');

Route::post('/logout', function (Request $request) {
    Auth::logout();
    $request->session()->invalidate();
    $request->session()->regenerateToken();
    return redirect()->route('projects.index');
})->name('logout');
// ------------------- Core resources -------------------
Route::resource('projects', ProjectController::class);
Route::get('/issues', [IssueController::class, 'index'])->name('issues.index');

// Issues are tied to projects for create/store; shallow for show/edit/update/destroy
Route::resource('projects.issues', IssueController::class)->shallow();

// Tags: simple list + create (PRITECH requires create/list)
Route::resource('tags', TagController::class)->only(['index', 'store']);

// ------------------- AJAX: Comments (list + create) -------------------
Route::get   ('/issues/{issue}/comments', [IssueCommentController::class, 'index'])
    ->name('issues.comments.index');
Route::post  ('/issues/{issue}/comments', [IssueCommentController::class, 'store'])
    ->middleware('throttle:6,1')
    ->name('issues.comments.store');

// ------------------- AJAX: Tags attach/detach -------------------
Route::post  ('/issues/{issue}/tags/{tag}', [IssueTagController::class, 'attach'])
    ->name('issues.tags.attach');
Route::delete('/issues/{issue}/tags/{tag}', [IssueTagController::class, 'detach'])
    ->name('issues.tags.detach');

// ------------------- AJAX: Assignees attach/detach (bonus) -------------------
Route::post  ('/issues/{issue}/assignees/{user}', [IssueAssigneeController::class, 'attach'])
    ->name('issues.assignees.attach');
Route::delete('/issues/{issue}/assignees/{user}', [IssueAssigneeController::class, 'detach'])
    ->name('issues.assignees.detach');

// ------------------- Optional: 404 fallback (keeps logs clean) -------------------
Route::fallback(function () {
    return redirect()->route('projects.index');
});
