<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CommentStoreRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'author_name' => 'required|string|max:80',
            'body'        => 'required|string|max:2000',
        ];
    }
}
