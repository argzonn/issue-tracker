import './bootstrap';
import './assignees.js';
import './tags.js';
import './comments.js';
import './issue-search.js';
