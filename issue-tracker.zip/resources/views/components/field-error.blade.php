@props(['name'])
@error($name)
  <div class="text-danger small mt-1">{{ $message }}</div>
@enderror
