@php $map = ['low'=>'secondary','medium'=>'info','high'=>'danger']; @endphp
<span class="badge text-bg-{{ $map[$priority] ?? 'light' }}">{{ ucfirst($priority) }}</span>
