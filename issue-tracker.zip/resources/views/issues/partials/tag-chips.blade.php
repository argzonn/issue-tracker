<div id="tag-chips" class="d-flex flex-wrap gap-2">
  @forelse($issue->tags as $tag)
    <span class="badge rounded-pill" style="background: {{ $tag->color ?? '#e9ecef' }}; color: #000">
      {{ e($tag->name) }}
      @can('update', $issue->project)
      <button type="button"
              class="btn btn-sm btn-link p-0 ms-1 text-decoration-none"
              data-action="detach-tag" data-tag="{{ $tag->id }}"
              aria-label="Remove tag">×</button>
      @endcan
    </span>
  @empty
    <span class="text-muted">No tags</span>
  @endforelse
</div>
