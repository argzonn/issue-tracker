<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-start mb-2">
    <div>
        <h1 class="mb-1"><?php echo e($project->name); ?></h1>
        <p class="text-muted mb-0">
            <?php echo e($project->start_date); ?> → <?php echo e($project->deadline); ?>

        </p>
        <?php if($project->owner): ?>
            <p class="text-muted mb-0">Owner: <?php echo e($project->owner->name); ?></p>
        <?php endif; ?>
    </div>

    <div class="text-end">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $project)): ?>
            <a class="btn btn-sm btn-outline-secondary" href="<?php echo e(route('projects.edit', $project)); ?>">Edit</a>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $project)): ?>
            <form class="d-inline" method="POST" action="<?php echo e(route('projects.destroy', $project)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this project?')">
                    Delete
                </button>
            </form>
        <?php endif; ?>
    </div>
</div>

<p class="mt-3"><?php echo e($project->description); ?></p>

<hr>

<h3>Issues</h3>
<table class="table">
  <thead>
    <tr>
      <th>Title</th>
      <th>Status</th>
      <th>Priority</th>
      <th>Due</th>
    </tr>
  </thead>
  <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $project->issues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <tr>
        <td><a href="<?php echo e(route('issues.show', $i)); ?>"><?php echo e($i->title); ?></a></td>
        <td><?php echo e($i->status); ?></td>
        <td><?php echo e($i->priority); ?></td>
        <td><?php echo e($i->due_date); ?></td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <tr>
        <td colspan="4" class="text-muted">No issues in this project.</td>
      </tr>
    <?php endif; ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/argzon/issue-tracker/resources/views/projects/show.blade.php ENDPATH**/ ?>