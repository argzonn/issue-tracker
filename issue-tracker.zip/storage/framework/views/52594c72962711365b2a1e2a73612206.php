<?php $__env->startSection('title', 'Issues'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="mb-0">Issues</h1>
    <?php if(auth()->guard()->check()): ?>
      <a href="<?php echo e(route('issues.create')); ?>" class="btn btn-primary">New Issue</a>
    <?php endif; ?>
  </div>

  
  <form class="row g-2 mb-3" method="GET" action="<?php echo e(route('issues.index')); ?>" autocomplete="off">
    
    <div class="col-md-4">
      <input name="q"
             class="form-control"
             placeholder="Search title or description…"
             value="<?php echo e(request('q', '')); ?>">
    </div>

    
    <div class="col-md-2">
      <select name="status" class="form-select" onchange="this.form.submit()">
        <option value="">Status</option>
        <?php $__currentLoopData = \App\Models\Issue::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($s); ?>" <?php if(request('status')===$s): echo 'selected'; endif; ?>><?php echo e(\Illuminate\Support\Str::headline($s)); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    
    <div class="col-md-2">
      <select name="priority" class="form-select" onchange="this.form.submit()">
        <option value="">Priority</option>
        <?php $__currentLoopData = \App\Models\Issue::PRIORITIES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($p); ?>" <?php if(request('priority')===$p): echo 'selected'; endif; ?>><?php echo e(\Illuminate\Support\Str::headline($p)); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    
    <div class="col-md-2">
      <select name="tag_id" class="form-select" onchange="this.form.submit()">
        <option value="">Tag</option>
        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($t->id); ?>" <?php if((string)request('tag_id')===(string)$t->id): echo 'selected'; endif; ?>><?php echo e($t->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    
    <div class="col-md-2">
      <?php $sort = request('sort'); ?>
      <select name="sort" class="form-select" onchange="this.form.submit()">
        <option value="">Sort: Newest</option>
        <option value="due_asc"   <?php if($sort==='due_asc'): echo 'selected'; endif; ?>>Due date ↑</option>
        <option value="due_desc"  <?php if($sort==='due_desc'): echo 'selected'; endif; ?>>Due date ↓</option>
        <option value="prio_asc"  <?php if($sort==='prio_asc'): echo 'selected'; endif; ?>>Priority ↑</option>
        <option value="prio_desc" <?php if($sort==='prio_desc'): echo 'selected'; endif; ?>>Priority ↓</option>
      </select>
    </div>

    <div class="col-12 d-flex gap-2 mt-1">
      <a class="btn btn-outline-secondary btn-sm" href="<?php echo e(route('issues.index')); ?>">Clear</a>
      <button type="submit" class="btn btn-primary btn-sm">Apply</button>
    </div>
  </form>

  <?php
    $statusMap   = ['open'=>'secondary','in_progress'=>'info','closed'=>'success'];
    $priorityMap = ['low'=>'secondary','medium'=>'primary','high'=>'warning','urgent'=>'danger'];
  ?>

  <div class="table-responsive">
    <table class="table align-middle">
      <thead>
        <tr>
          <th style="width:70px;">#</th>
          <th>Title</th>
          <th style="width:18%;">Project</th>
          <th style="width:12%;">Status</th>
          <th style="width:12%;">Priority</th>
          <th style="width:10%;">Due</th>
          <th style="width:10%;">Comments</th>
        </tr>
      </thead>
      <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $issues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          
          <td>
            <?php if($issues instanceof \Illuminate\Pagination\LengthAwarePaginator || $issues instanceof \Illuminate\Pagination\Paginator): ?>
              <?php echo e($issues->firstItem() + $loop->index); ?>

            <?php else: ?>
              <?php echo e($loop->iteration); ?>

            <?php endif; ?>
          </td>

          <td>
            <a href="<?php echo e(route('issues.show', $issue)); ?>"><?php echo e($issue->title); ?></a>
            <div class="text-muted small"><?php echo e(\Illuminate\Support\Str::limit($issue->description, 140)); ?></div>
          </td>

          <td><?php echo e($issue->project?->name ?? '—'); ?></td>

          <td>
            <?php $cls = $statusMap[$issue->status] ?? 'secondary'; ?>
            <span class="badge bg-<?php echo e($cls); ?>"><?php echo e(\Illuminate\Support\Str::headline($issue->status)); ?></span>
          </td>

          <td>
            <?php $cls = $priorityMap[$issue->priority] ?? 'secondary'; ?>
            <span class="badge bg-<?php echo e($cls); ?>"><?php echo e(\Illuminate\Support\Str::headline($issue->priority)); ?></span>
          </td>

          <td><?php echo e(optional($issue->due_date)->toDateString() ?? '—'); ?></td>
          <td><?php echo e($issue->comments()->count()); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="7" class="text-center text-muted">No issues found.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  
  <?php echo e($issues->withQueryString()->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/argzon/issue-tracker/resources/views/issues/index.blade.php ENDPATH**/ ?>