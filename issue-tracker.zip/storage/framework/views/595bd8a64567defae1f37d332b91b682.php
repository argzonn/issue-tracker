<?php
    // $project is passed on edit; absent on create
    $p = $project ?? null;

    // format dates for <input type="date">
    $startVal    = old('start_date', optional($p?->start_date)->format('Y-m-d'));
    $deadlineVal = old('deadline',   optional($p?->deadline)->format('Y-m-d'));
?>


<div class="mb-3">
  <label for="name" class="form-label">Name</label>
  <input
    id="name"
    name="name"
    class="form-control"
    type="text"
    value="<?php echo e(old('name', $p->name ?? '')); ?>"
    maxlength="255"
    required
  >
  <?php if (isset($component)) { $__componentOriginal45c27ef3e6d5d72689a68e0d58751167 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field-error','data' => ['name' => 'name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $attributes = $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $component = $__componentOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?>
</div>


<div class="mb-3">
  <label for="description" class="form-label">Description</label>
  <textarea
    id="description"
    name="description"
    class="form-control"
    rows="3"
    maxlength="20000"
  ><?php echo e(old('description', $p->description ?? '')); ?></textarea>
  <?php if (isset($component)) { $__componentOriginal45c27ef3e6d5d72689a68e0d58751167 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field-error','data' => ['name' => 'description']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'description']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $attributes = $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $component = $__componentOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?>
</div>

<div class="row">
  
  <div class="col-md-6 mb-3">
    <label for="start_date" class="form-label">Start date</label>
    <input
      id="start_date"
      type="date"
      name="start_date"
      class="form-control"
      value="<?php echo e($startVal); ?>"
    >
    <?php if (isset($component)) { $__componentOriginal45c27ef3e6d5d72689a68e0d58751167 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field-error','data' => ['name' => 'start_date']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'start_date']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $attributes = $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $component = $__componentOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?>
  </div>

  
  <div class="col-md-6 mb-3">
    <label for="deadline" class="form-label">Deadline</label>
    <input
      id="deadline"
      type="date"
      name="deadline"
      class="form-control"
      value="<?php echo e($deadlineVal); ?>"
    >
    <?php if (isset($component)) { $__componentOriginal45c27ef3e6d5d72689a68e0d58751167 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field-error','data' => ['name' => 'deadline']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'deadline']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $attributes = $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $component = $__componentOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?>
  </div>
</div>


<div class="form-check mb-3">
  
  <input type="hidden" name="is_public" value="0">
  <input
    class="form-check-input"
    type="checkbox"
    id="is_public"
    name="is_public"
    value="1"
    <?php echo e(old('is_public', $p->is_public ?? false) ? 'checked' : ''); ?>

  >
  <label class="form-check-label" for="is_public">Public project</label>
  <?php if (isset($component)) { $__componentOriginal45c27ef3e6d5d72689a68e0d58751167 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field-error','data' => ['name' => 'is_public']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'is_public']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $attributes = $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $component = $__componentOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?>
</div>
<?php /**PATH /Users/argzon/issue-tracker/resources/views/projects/form.blade.php ENDPATH**/ ?>