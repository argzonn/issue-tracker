<?php $__env->startSection('content'); ?>
<div class="container" style="max-width:720px;">
  <h1 class="mb-3">Tags</h1>

  <?php if(session('status')): ?>
    <div class="alert alert-success"><?php echo e(session('status')); ?></div>
  <?php endif; ?>

  <form method="POST" action="<?php echo e(route('tags.store')); ?>" class="row g-2 mb-4" autocomplete="off">
    <?php echo csrf_field(); ?>
    <div class="col-md-5">
      <input name="name" class="form-control" placeholder="Name" value="<?php echo e(old('name')); ?>" required>
      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-5">
      <div class="input-group">
        <span class="input-group-text">#</span>
        <input name="color" class="form-control" placeholder="ff9900 (optional)" value="<?php echo e(ltrim(old('color',''), '#')); ?>">
      </div>
      <div class="form-text">3 or 6 hex digits. “#” optional — we’ll normalize.</div>
      <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-2">
      <button class="btn btn-primary w-100">Add</button>
    </div>
  </form>

  <table class="table align-middle">
    <thead>
      <tr>
        <th style="width:40%;">Name</th>
        <th style="width:30%;">Color</th>
        <th style="width:30%;" class="text-end">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><?php echo e($t->name); ?></td>
          <td>
            <?php if($t->color): ?>
              <span style="display:inline-block;width:14px;height:14px;border-radius:50%;background:<?php echo e($t->color); ?>;vertical-align:middle;margin-right:6px;"></span>
              <code><?php echo e($t->color); ?></code>
            <?php else: ?>
              <span class="text-muted">—</span>
            <?php endif; ?>
          </td>
          <td class="text-end">
            <a href="<?php echo e(route('tags.edit', $t)); ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
            <form action="<?php echo e(route('tags.destroy', $t)); ?>" method="POST" class="d-inline"
                  onsubmit="return confirm('Delete this tag? This cannot be undone.')">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button class="btn btn-sm btn-outline-danger">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="3" class="text-center text-muted">No tags yet.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>

  <?php echo e($tags->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/argzon/issue-tracker/resources/views/tags/index.blade.php ENDPATH**/ ?>