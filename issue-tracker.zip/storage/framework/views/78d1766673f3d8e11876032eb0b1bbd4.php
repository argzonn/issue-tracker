<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>Issue Tracker</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-light bg-light mb-3">
  <div class="container d-flex justify-content-between align-items-center">
    <a class="navbar-brand" href="<?php echo e(route('projects.index')); ?>">Issue Tracker</a>
    <div class="d-flex gap-2 align-items-center">
      <?php if(auth()->guard()->check()): ?>
        <span class="me-2">Hello, <?php echo e(auth()->user()->name); ?></span>
        <form action="<?php echo e(route('logout')); ?>" method="POST" class="m-0">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-sm btn-outline-secondary">Logout</button>
        </form>
      <?php else: ?>
        <a href="<?php echo e(route('login')); ?>" class="btn btn-sm btn-outline-secondary">Login</a>
      <?php endif; ?>

      <a class="btn btn-link" href="<?php echo e(route('projects.index')); ?>">Projects</a>
      <a class="btn btn-link" href="<?php echo e(route('issues.index')); ?>">Issues</a>
      <a class="btn btn-link" href="<?php echo e(route('tags.index')); ?>">Tags</a>
    </div>
  </div>
</nav>

<div class="container">
  <?php if(session('ok')): ?> <div class="alert alert-success"><?php echo e(session('ok')); ?></div> <?php endif; ?>
  <?php echo $__env->yieldContent('content'); ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /Users/argzon/issue-tracker/resources/views/layouts/app.blade.php ENDPATH**/ ?>