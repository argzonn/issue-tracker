<?php $__env->startSection('content'); ?>
<h1 class="mb-3">Projects</h1>

<?php if(auth()->guard()->check()): ?>
  <a class="btn btn-primary mb-3" href="<?php echo e(route('projects.create')); ?>">New Project</a>
<?php endif; ?>

<table class="table align-middle">
  <thead>
    <tr>
      <th>Name</th>
      <th>Start</th>
      <th>Deadline</th>
      <th>Issues</th>
      <th class="text-end">Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <tr>
        <td>
          <a href="<?php echo e(route('projects.show', $p)); ?>"><?php echo e($p->name); ?></a>
          <?php if($p->is_public): ?>
            <span class="badge text-bg-success ms-1">Public</span>
          <?php else: ?>
            <span class="badge text-bg-secondary ms-1">Private</span>
          <?php endif; ?>
        </td>

        <td><?php echo e(optional($p->start_date)->format('Y-m-d') ?? '—'); ?></td>
        <td><?php echo e(optional($p->deadline)->format('Y-m-d') ?? '—'); ?></td>

        <td><?php echo e($p->issues_count); ?></td>

        <td class="text-end">
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $p)): ?>
            <a class="btn btn-sm btn-outline-secondary" href="<?php echo e(route('projects.edit', $p)); ?>">Edit</a>
          <?php endif; ?>

          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $p)): ?>
            <form class="d-inline" method="POST" action="<?php echo e(route('projects.destroy', $p)); ?>">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button class="btn btn-sm btn-outline-danger"
                      onclick="return confirm('Delete this project? This cannot be undone.')">
                Del
              </button>
            </form>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <tr>
        <td colspan="5" class="text-muted">No projects yet.</td>
      </tr>
    <?php endif; ?>
  </tbody>
</table>

<?php echo e($projects->withQueryString()->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/argzon/issue-tracker/resources/views/projects/index.blade.php ENDPATH**/ ?>