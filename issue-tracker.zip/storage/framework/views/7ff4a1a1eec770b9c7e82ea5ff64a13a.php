<?php $__env->startSection('content'); ?>
<div class="container" style="max-width:720px;">
  <h1>Edit Project</h1>
  <form method="POST" action="<?php echo e(route('projects.update',$project)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <?php echo $__env->make('projects.form',['project'=>$project], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <button class="btn btn-primary">Save</button>
    <a class="btn btn-link" href="<?php echo e(route('projects.show',$project)); ?>">Cancel</a>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/argzon/issue-tracker/resources/views/projects/edit.blade.php ENDPATH**/ ?>