<?php $__env->startSection('content'); ?>
<div class="container" style="max-width: 420px; margin: 2rem auto;">
    <h1 style="margin-bottom:1rem;">Sign in</h1>

    <?php if($errors->any()): ?>
        <div style="background:#fee; border:1px solid #f99; padding:.75rem; margin-bottom:1rem;">
            <ul style="margin:0; padding-left:1.25rem;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($e); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('login.perform')); ?>">
        <?php echo csrf_field(); ?>
        <div style="margin-bottom:.75rem;">
            <label for="email">Email</label>
            <input id="email" name="email" type="email"
                   value="<?php echo e(old('email')); ?>" required autofocus
                   style="display:block; width:100%; padding:.5rem; border:1px solid #ccc; border-radius:4px;">
        </div>

        <div style="margin-bottom:.75rem;">
            <label for="password">Password</label>
            <input id="password" name="password" type="password" required
                   style="display:block; width:100%; padding:.5rem; border:1px solid #ccc; border-radius:4px;">
        </div>

        <div style="margin-bottom:1rem;">
            <label style="display:flex; gap:.5rem; align-items:center;">
                <input type="checkbox" name="remember" value="1">
                <span>Remember me</span>
            </label>
        </div>

        <button type="submit"
            style="padding:.5rem 1rem; border:0; background:#1f6feb; color:#fff; border-radius:4px;">
            Sign in
        </button>
    </form>

    <p style="margin-top:1rem; color:#666;">
        Try: <code>owner@example.com</code> / <code>password</code>
    </p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/argzon/issue-tracker/resources/views/auth/login.blade.php ENDPATH**/ ?>