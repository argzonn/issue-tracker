<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="border rounded p-2 mb-2">
    <div class="small text-muted"><?php echo e(e($c->author_name)); ?> • <?php echo e($c->created_at->diffForHumans()); ?></div>
    <div><?php echo e(e($c->body)); ?></div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /Users/argzon/issue-tracker/resources/views/issues/partials/comment-items.blade.php ENDPATH**/ ?>