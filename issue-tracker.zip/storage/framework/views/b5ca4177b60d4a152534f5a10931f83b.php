<div id="tag-chips" class="d-flex flex-wrap gap-2">
  <?php $__empty_1 = true; $__currentLoopData = $issue->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <span class="badge rounded-pill" style="background: <?php echo e($tag->color ?? '#e9ecef'); ?>; color: #000">
      <?php echo e(e($tag->name)); ?>

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $issue->project)): ?>
        <button class="btn btn-sm btn-link p-0 ms-1 text-decoration-none"
                data-action="detach-tag"
                data-tag="<?php echo e($tag->id); ?>"
                aria-label="Remove tag">×</button>
      <?php endif; ?>
    </span>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <span class="text-muted">No tags</span>
  <?php endif; ?>
</div>
<?php /**PATH /Users/argzon/issue-tracker/resources/views/issues/partials/tag-chips.blade.php ENDPATH**/ ?>